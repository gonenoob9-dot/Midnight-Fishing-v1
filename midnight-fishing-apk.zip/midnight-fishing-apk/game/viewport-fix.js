// Android WebView can keep a stale (portrait) viewport right after launch/rotation.
// Re-announce the real size a few times so layout and touch areas get recalculated.
(function () {
  var kick = function () { window.dispatchEvent(new Event('resize')); };
  [0, 150, 400, 900, 1800, 3500].forEach(function (d) { setTimeout(kick, d); });
  window.addEventListener('load', function () { setTimeout(kick, 50); });
  window.addEventListener('orientationchange', function () { setTimeout(kick, 100); setTimeout(kick, 500); });
  if (window.visualViewport) window.visualViewport.addEventListener('resize', kick);
})();
