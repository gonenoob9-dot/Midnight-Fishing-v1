#!/usr/bin/env bash
set -euo pipefail
npm install
node scripts/prepare.mjs
npx cap add android

MANIFEST=android/app/src/main/AndroidManifest.xml
sed -i 's|<activity|<activity android:screenOrientation="sensorLandscape"|' "$MANIFEST"
MAIN=$(find android/app/src/main/java -name MainActivity.java)
PKG=$(grep -m1 '^package' "$MAIN" | sed 's/package \(.*\);/\1/')
cat > "$MAIN" <<JAVA
package $PKG;

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
  }
  @Override
  public void onWindowFocusChanged(boolean hasFocus) {
    super.onWindowFocusChanged(hasFocus);
    if (hasFocus) {
      getWindow().getDecorView().setSystemUiVisibility(
        View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
        | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }
  }
}
JAVA

cp -r icon/res/. android/app/src/main/res/
npx cap sync android
(cd android && ./gradlew assembleDebug --no-daemon)
