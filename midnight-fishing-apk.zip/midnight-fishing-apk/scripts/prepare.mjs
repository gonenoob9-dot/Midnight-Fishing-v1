// Builds ./www from ./game and makes it fully offline (Three.js + fonts bundled).
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const nm = (p) => path.join(root, 'node_modules', p);
const www = path.join(root, 'www');

fs.rmSync(www, { recursive: true, force: true });
fs.cpSync(path.join(root, 'game'), www, { recursive: true });

// ---- Three.js (only the parts the game imports) ----
const t = path.join(www, 'lib/three');
fs.mkdirSync(path.join(t, 'build'), { recursive: true });
fs.copyFileSync(nm('three/build/three.module.js'), path.join(t, 'build/three.module.js'));
for (const d of ['loaders', 'controls', 'utils']) {
  fs.cpSync(nm(`three/examples/jsm/${d}`), path.join(t, 'examples/jsm', d), { recursive: true });
}

// ---- Fonts (fontsource, only files referenced by the CSS) ----
const fonts = [
  ['bebas-neue', [400]], ['moul', [400]], ['koulen', [400]],
  ['noto-sans-khmer', [400, 700]], ['special-elite', [400]],
];
let links = '';
for (const [pkg, weights] of fonts) {
  for (const w of weights) {
    const cssSrc = nm(`@fontsource/${pkg}/${w}.css`);
    if (!fs.existsSync(cssSrc)) { console.warn(`! missing font css: ${pkg} ${w}`); continue; }
    const outDir = path.join(www, 'fonts', pkg);
    fs.mkdirSync(path.join(outDir, 'files'), { recursive: true });
    const css = fs.readFileSync(cssSrc, 'utf8');
    for (const m of css.matchAll(/url\(\.\/files\/([^)]+?\.woff2)\)/g)) {
      fs.copyFileSync(nm(`@fontsource/${pkg}/files/${m[1]}`), path.join(outDir, 'files', m[1]));
    }
    // keep only woff2 sources
    fs.writeFileSync(path.join(outDir, `${w}.css`),
      css.replace(/,\s*url\(\.\/files\/[^)]+?\.woff\)\s*format\("woff"\)/g, ''));
    links += `<link rel="stylesheet" href="fonts/${pkg}/${w}.css">\n`;
  }
}

// ---- Rewrite index.html to use local files ----
const idx = path.join(www, 'index.html');
let html = fs.readFileSync(idx, 'utf8');
html = html
  .replace(/<link rel="preconnect"[^>]*>\s*/g, '')
  .replace(/<link href="https:\/\/fonts\.googleapis\.com[^>]*>/, links.trim())
  .replaceAll('https://unpkg.com/three@0.160.0/', './lib/three/');
fs.writeFileSync(idx, html);

if (/unpkg\.com|googleapis|gstatic/.test(html)) {
  console.error('ERROR: index.html still references an online resource'); process.exit(1);
}
if (!links) { console.error('ERROR: no fonts bundled'); process.exit(1); }
console.log('www ready');
